
$( ".fa-bars" ).click(function() {
  $("#toolbar").css('margin-left', '0px');
  $(".fa-bars").css('display', 'none');
});
$( ".fa-times" ).click(function() {
  $("#toolbar").css('margin-left', '-270px');
  $(".fa-bars").css('display', 'block');
  $(".fa-bars").css('opacity', '1');
});

$( ".new-card" ).click(function() {
  $(".new-card").addClass('activated');
});

$(function(){
    var NewContent='<div class="grid-inner"></div>'
    $(".new-card").click(function(){     
      $(".grid").prepend(NewContent);
    });
});